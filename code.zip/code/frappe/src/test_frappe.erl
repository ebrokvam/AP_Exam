-module(test_frappe).

-export([test_all/0, test_everything/0]).
-export([mktrans/2, terminating_transformation/1, prop_cache_under_capacity/0, prop_capacity_invariant/0]). % Remember to export the other functions from Q2.2

-include_lib("eqc/include/eqc.hrl").

% You are allowed to split your testing code in as many files as you
% think is appropriate, just remember that they should all start with
% 'test_'.
% But you MUST have a module (this file) called test_frappe.

test_all() ->
  ok.

test_everything() ->
  test_all().

-type key() :: term().
-type value() :: term().
-type cost() :: pos_integer().
-type transformation() :: fun(({existing, value()} | new) ->
                              {new_value, value(), cost()} | any()).

mktrans(Ops, Args) -> undefined.

terminating_transformation(KeyGen) -> undefined.

prop_cache_under_capacity() -> undefined.

%% For all caches, 

prop_capacity_invariant() -> undefined.

key() ->
    oneof([atom(), int(), real()]).

value() -> int().
capacity() -> int().

atom() ->
    elements([a,b,c,d]).

%% prop for no duplicate keys

%% TODO: use limited versions if I don't implement stable/2


%% transformation functions