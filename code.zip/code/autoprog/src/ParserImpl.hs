-- Put your Parser implementation in this file
module ParserImpl where

import Defs
-- import either ReadP or Parsec, as relevant

parseStringType :: String -> EM PType
parseStringType = undefined

parseStringTDeclz :: String -> EM [TDecl]
parseStringTDeclz = undefined
