-- Do not modify this file. Put your Resolver code in ResolverImpl
module Resolver (resolve, declare) where

import ResolverImpl
